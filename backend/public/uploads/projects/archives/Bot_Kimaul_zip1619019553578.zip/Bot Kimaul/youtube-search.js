const axios = require('axios')
const mysql = require('mysql')
const keyApi = 'AIzaSyDDsAhOSMC-DXB089QhYLGTohzxgOMDwBw'
const channelId = 'UCUjo_IKa9Cqkx_x-rMly8MA';
const playListId = 'PLuWyq_EO5_ALOnpxptlqQA5FR75Nza2PQ'
var db = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	password: 'Io73uh96/&*',
	database: 'dev'
});
db.connect(function (err) {
	if (err) {
		console.error('Mysql error connecting: ' + err.stack);
		return;
	}

	console.log('Mysql connected as id: ' + db.threadId);
});
function fetchYoutubeChannel(urlChaine) {
	db.query('SELECT * FROM youtube WHERE type = "channel"',(err, results) =>{
		if(err) console.log(err)
		else {
			if(!results && !result.length) return;
			for(const result of results){
				const urlChaine = `https://www.googleapis.com/youtube/v3/search?key=${keyApi}&channelId=${result.channel_id}&part=snippet,id&order=date&maxResults=20`
				axios.get(urlChaine).then(responce => {
					const resID = responce.data.items[0].id.videoId
					db.query('SELECT * FROM logs_youtube WHERE video_id = ?',[resID],(err, result) =>{
						if(err) return console.error(err)
						else {
							if(!result || result && !result.length) {
								client.channels.get(result.discord_channel_id).send('Nouvelle vidéo : ' + `https://youtube.com/watch?v=${resID}`)
								db.query('INSERT INTO logs_youtube (video_id) VALUES (?)',[resID]), (err, result) => {
									if(err) return console.error(err)
								}
							}else console.log('Pas de nouvelle vidéo')
						}
					})
				})
			}
		}
	})

}
function fetchYoutubePlaylist(url) {
	db.query('SELECT * FROM youtube WHERE type = "playlist"',(err, results) =>{
		if(err) console.log(err)
		else {
			if(!results && !result.length) return;
			for(const result of results){
				const urlChaine = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=2&playlistId=${result.channel_id}&key=${keyApi}`
				axios.get(urlChaine).then(responce => {
					const resID = responce.data.items[0].snippet.resourceId.videoId
					db.query('SELECT * FROM logs_youtube WHERE video_id = ?',[resID],(err, result) =>{
						if(err) return console.error(err)
						else {
							if(!result || result && !result.length) {
								console.log('Nouvelle vidéo !')
								db.query('INSERT INTO logs_youtube (video_id) VALUES (?)',[resID]), (err, result) => {
									if(err) return console.error(err)
								}
							}else console.log('Pas de nouvelle vidéo')
						}
					})
				})
			}
		}
	})
}
fetchYoutubeChannel()
fetchYoutubePlaylist()