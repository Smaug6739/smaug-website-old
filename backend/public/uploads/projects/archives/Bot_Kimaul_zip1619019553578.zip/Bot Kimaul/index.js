const fs = require('fs');
const rimraf = require("rimraf");
const moment = require("moment");
const axios = require('axios')
const ms = require("ms");
const mysql = require('mysql')
const { GiveawaysManager } = require("discord-giveaways");
const Discord = require('discord.js');
const keyApi = 'AIzaSyDDsAhOSMC-DXB089QhYLGTohzxgOMDwBw'
const bot = new Discord.Client()
const manager = new GiveawaysManager(bot, {
    storage: "./giveaways.json",
    updateCountdownEvery: 10000,
    default: {
        botsCanWin: false,
        exemptPermissions: ["MANAGE_MESSAGES", "ADMINISTRATOR"],
        embedColor: "#3c3f41",
        reaction: "🎉"
    }
});

bot.giveawaysManager = manager;
var db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Io73uh96/&*',
    database: 'dev'
});
db.connect(function (err) {
    if (err) {
        console.error('Mysql error connecting: ' + err.stack);
        return;
    }

    console.log('Mysql connected as id: ' + db.threadId);
});
function fetchYoutubeChannel() {
    db.query('SELECT * FROM youtube WHERE type = "channel"',(err, results) =>{
        if(err) console.log(err)
        else {
            if(!results && !result.length) return;
            for(const resultCommand of results){
                const urlChaine = `https://www.googleapis.com/youtube/v3/search?key=${keyApi}&channelId=${resultCommand.channel_id}&part=snippet,id&order=date&maxResults=5`
                axios.get(urlChaine)
                    .then(responce => {
                    const resID = responce.data.items[0].id.videoId
                    db.query('SELECT * FROM logs_youtube WHERE video_id = ?',[resID],(err, result) =>{
                        if(err) return console.error(err)
                        else {
                            if(!result || result && !result.length) {
                                bot.channels.get(resultCommand.discord_channel_id).send('Nouvelle vidéo : ' + `https://youtube.com/watch?v=${resID}`)
                                db.query('INSERT INTO logs_youtube (video_id) VALUES (?)',[resID]), (err, result) => {
                                    if(err) return console.error(err)
                                }
                            }else console.log('Pas de nouvelle vidéo')
                        }
                    })
                })
                    .catch(err => console.log(err.message))
            }
        }
    })

}
function fetchYoutubePlaylist() {
    db.query('SELECT * FROM youtube WHERE type = "playlist"',(err, results) =>{
        if(err) console.log(err)
        else {
            if(!results && !result.length) return;
            for(const result of results){
                const urlChaine = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=2&playlistId=${result.channel_id}&key=${keyApi}`
                axios.get(urlChaine)
                    .then(responce => {
                    const resID = responce.data.items[0].snippet.resourceId.videoId
                    db.query('SELECT * FROM logs_youtube WHERE video_id = ?',[resID],(err, result) =>{
                        if(err) return console.error(err)
                        else {
                            if(!result || result && !result.length) {
                                bot.channels.get(resultCommand.discord_channel_id).send('Nouvelle vidéo : ' + `https://youtube.com/watch?v=${resID}`)
                                db.query('INSERT INTO logs_youtube (video_id) VALUES (?)',[resID]), (err, result) => {
                                    if(err) return console.error(err)
                                }
                            }else console.log('Pas de nouvelle vidéo')
                        }
                    })
                })
                    .catch(err => console.log(err.message))
            }
        }
    })
}
bot.login('NzI3MTk4MzI0MzM5MjQ1MDU3.XvoaQA.fHRiipbrgncHIujKTjc1kDjhq9E');


bot.on('ready', () => {
    console.log('Le bot est prêt');
    console.log('Développé par LProgead#3667 de LShop');
    checkbh();
    //stats();
    setInterval(checkbh, 60000);
    setInterval(fetchYoutubeChannel, 120000);
    setInterval(fetchYoutubePlaylist, 120000);

    //setInterval(stats, 60000);

});

bot.on('message', message => {
    if (message.author === bot.user) return;
    const args = message.content.split(' ');
    if(message.content.startsWith('+ytb-channel')){
        if(!message.member.permissions.has('MANAGE_CHANNELS')) return message.channel.send('Vous n\'avez pas les bonnes permissions.')
        const channelID = args[1]
        db.query('INSERT INTO youtube (`type`,`channel_id`,`discord_channel_id`) VALUES ("channel",?,?)',[channelID,message.channel.id],(err, result) =>{
            if(err) return console.log(err)
            else message.channel.send(`Ajouté avec succès`)
        })
    }
    if (message.content.startsWith('+youtube')) {
        const args = message.content.split(' ');
        fs.writeFile('youtube.json', JSON.stringify(), (err) => {
            if (err) throw err;

            console.log('Users saved!');
        });
    }

    message.content.toLowerCase().split(' ').forEach(element => {
        if (fs.existsSync('word_check/' + element + ".txt")) {
            let men = fs.readFileSync('word_check/' + element + ".txt").toString();
            message.channel.send(men);

        }
    });

    if (fs.existsSync(message.channel.id)) {
        if (message.content.startsWith('+watch')) {
            if (fs.existsSync(message.channel.id)) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("Ce salon est déjà surveillé. Vous pouvez annuler la surveillance en utilisant la commande `+unwatch`.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            const tosend = message.content.replace(`+watch ${args[1]} ${args[2]} `, '');


            if (!args[1] || !args[2] || tosend === message.content) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("La syntaxe de cette commande est `+watch <messages/articles> <Nombre de messages/articles avant mention> <Message à envoyer lorsque le nombre est atteint>`.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            if (isNaN(args[2])) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("Le second arguement de surveillance doit être un chiffre.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            switch (args[1]) {
                case 'messages':
                    const okmsg = new Discord.RichEmbed()
                        .setAuthor(message.author.username, message.author.displayAvatarURL)
                        .setTitle('Surveillance du salon établie')
                        .setColor('FAFAFA')
                        .setFooter('Bot développé par LProgead#3667 de LShop')
                        .setTimestamp()
                    message.channel.send(okmsg);
                    fs.mkdirSync(message.channel.id);
                    fs.writeFileSync(message.channel.id + "/nbmen.txt", args[2]);
                    fs.writeFileSync(message.channel.id + "/men.txt", tosend);
                    fs.writeFileSync(message.channel.id + "/nbmsgs.txt", 1);
                    return;
                    break;

                case 'articles':
                    const okart = new Discord.RichEmbed()
                        .setAuthor(message.author.username, message.author.displayAvatarURL)
                        .setTitle('Surveillance du salon établie')
                        .setColor('FAFAFA')
                        .setFooter('Bot développé par LProgead#3667 de LShop')
                        .setTimestamp()
                    message.channel.send(okart);
                    fs.mkdirSync(message.channel.id);
                    fs.writeFileSync(message.channel.id + "/nbmen.txt", args[2]);
                    fs.writeFileSync(message.channel.id + "/men.txt", tosend);
                    fs.writeFileSync(message.channel.id + "/nbarticles.txt", 0);
                    return;
                    break;

                default:
                    const err = new Discord.RichEmbed()
                        .setAuthor(message.author.username, message.author.displayAvatarURL)
                        .setTitle('Une erreur est survenue')
                        .setDescription("Le premier argument de surveillance doit être `messages` ou `articles`.")
                        .setColor('FF2200')
                        .setFooter('Bot développé par LProgead#3667 de LShop')
                        .setTimestamp()
                    message.channel.send(err);
                    return;
                    break;
            }

            fs.mkdirSync(message.channel.id);
        }

        if (message.content.startsWith('+unwatch')) {
            if (!fs.existsSync(message.channel.id)) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("Le salon n'est pas sous surveillance.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            else {
                const okart = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Surveillance du salon annulée')
                    .setColor('FAFAFA')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(okart);
                rimraf.sync(message.channel.id, { recursive: true });
                return;
            }
        }

        if (fs.existsSync(message.channel.id + '/nbmsgs.txt')) {
            let nbmsgs = fs.readFileSync(message.channel.id + "/nbmsgs.txt").toString();
            let nbmen = fs.readFileSync(message.channel.id + "/nbmen.txt").toString();
            let men = fs.readFileSync(message.channel.id + "/men.txt").toString();

            if (nbmen === nbmsgs) {
                message.channel.send(men);
                fs.writeFileSync(message.channel.id + "/nbmsgs.txt", "1");
            }

            else {
                fs.writeFileSync(message.channel.id + "/nbmsgs.txt", (parseInt(nbmsgs) + parseInt(1)).toString());
            }
        }

        else {
            let art = message.content.split('https://').length - 1;
            var nbarts = fs.readFileSync(message.channel.id + "/nbarticles.txt").toString();
            fs.writeFileSync(message.channel.id + "/nbarticles.txt", parseInt(nbarts) + parseInt(art).toString());
            let nbmen = fs.readFileSync(message.channel.id + "/nbmen.txt").toString();
            let men = fs.readFileSync(message.channel.id + "/men.txt").toString();
            var nbarts = fs.readFileSync(message.channel.id + "/nbarticles.txt").toString();

            if (nbarts >= nbmen) {
                message.channel.send(men);
                fs.writeFileSync(message.channel.id + "/nbarticles.txt", "0");
            }
        }
    }

    if (!message.content.startsWith('+')) return;

    if (message.content.startsWith('+addword')) {
        if (!message.member.hasPermission('ADMINISTRATOR')) return;

        const word = message.content.split(' ')[1];
        const to_send = message.content.replace('+addword ' + word, '');

        if (!word) {
            const err = new Discord.RichEmbed()
                .setAuthor(message.author.username, message.author.displayAvatarURL)
                .setTitle('Une erreur est survenue')
                .setDescription("Veuillez préciser le mot à détecter.")
                .setColor('FF2200')
                .setFooter('Bot développé par LProgead#3667 de LShop')
                .setTimestamp()
            message.channel.send(err);
            return;
        }

        if (message === message.content.replace('+addword ' + word)) {
            const err = new Discord.RichEmbed()
                .setAuthor(message.author.username, message.author.displayAvatarURL)
                .setTitle('Une erreur est survenue')
                .setDescription("Veuillez préciser le message à envoyer si le mot est détecté.")
                .setColor('FF2200')
                .setFooter('Bot développé par LProgead#3667 de LShop')
                .setTimestamp()
            message.channel.send(err);
            return;
        }

        fs.writeFileSync('word_check/' + word + ".txt", to_send);

        const okmsg = new Discord.RichEmbed()
            .setAuthor(message.author.username, message.author.displayAvatarURL)
            .setTitle('Surveillance du mot établie')
            .setColor('FAFAFA')
            .setFooter('Bot développé par LProgead#3667 de LShop')
            .setTimestamp()
        message.channel.send(okmsg);
        return;
    }

    if (message.content.startsWith('+remword')) {
        if (!message.member.hasPermission('ADMINISTRATOR')) return;

        const word = message.content.split(' ')[1];

        if (!word) {
            const err = new Discord.RichEmbed()
                .setAuthor(message.author.username, message.author.displayAvatarURL)
                .setTitle('Une erreur est survenue')
                .setDescription("Veuillez préciser le mot à détecter.")
                .setColor('FF2200')
                .setFooter('Bot développé par LProgead#3667 de LShop')
                .setTimestamp()
            message.channel.send(err);
            return;
        }

        if (!fs.existsSync('word_check/' + word + ".txt")) {
            const err = new Discord.RichEmbed()
                .setAuthor(message.author.username, message.author.displayAvatarURL)
                .setTitle('Une erreur est survenue')
                .setDescription("Ce mot n'est pas sous surveillance.")
                .setColor('FF2200')
                .setFooter('Bot développé par LProgead#3667 de LShop')
                .setTimestamp()
            message.channel.send(err);
            return;
        }

        else {
            const okart = new Discord.RichEmbed()
                .setAuthor(message.author.username, message.author.displayAvatarURL)
                .setTitle('Surveillance du mot annulée')
                .setColor('FAFAFA')
                .setFooter('Bot développé par LProgead#3667 de LShop')
                .setTimestamp()
            message.channel.send(okart);
            fs.unlinkSync('word_check/' + word + ".txt");
            return;
        }
    }

    if ((!message.content.startsWith('+setbirthday') && !message.content.startsWith('+delbirthday') && !message.content.startsWith('+userinfo') && !message.content.startsWith('+roleinfo') && !message.content.startsWith('+serverinfo')) && !message.member.hasPermission('ADMINISTRATOR')) {
        const noperm = new Discord.RichEmbed()
            .setAuthor(message.author.username, message.author.displayAvatarURL)
            .setTitle('Permission manquante')
            .setDescription("Vous devez avoir la permission `ADMINISTRATOR` pour utiliser cette commande.")
            .setColor('FF2200')
            .setFooter('Bot développé par LProgead#3667 de LShop')
            .setTimestamp()
        message.channel.send(noperm);
        return;
    }

    if (!fs.existsSync(message.channel.id)) {
        if (message.content === "+help") {
            const help = new Discord.RichEmbed()
                .setAuthor(message.author.username, message.author.displayAvatarURL)
                .setTitle('Message d\'aide')
                .addField('+setbirthday <Date (jj/mm)>', 'Enregistrer votre date d\'anniversaire')
                .addField('+watch <messages/articles> <Nombre de messages/articles avant mention> <Message à envoyer lorsque le nombre est atteint>.', 'Vous permet de surveiller un salon.')
                .addField('+unwatch', 'Vous permet d\'annuler la surveillance d\'un salon.')
                .addField('+giveawaystart <Durée> <Nombre de gagnants> <Prix>', 'Vous permet de lancer un giveaway.')
                .addField('+giveawayend <ID du message du giveaway>', "Vous permet de stopper un giveaway prématurément.")
                .addField('+giveawayreroll <ID du message du giveaway>', 'Vous permet de définir un nouveau gagnant à un giveaway.')
                .setColor('FF2200')
                .setFooter('Bot développé par LProgead#3667 de LShop')
                .setTimestamp()
            message.channel.send(help);
            return;
        }

        if (message.content.startsWith("+userinfo")) {
            const moment = require('moment');
            const member = (message.mentions.members.first() || message.author);

            let tag;
            let avatarURL;
            let roles;
            let createdAt;
            let joinedAt;
            let status;

            switch (member.user) {
                case undefined:
                    tag = message.author.tag;
                    avatarURL = message.member.user.displayAvatarURL;
                    roles = message.member.roles;
                    createdAt = message.author.createdAt;
                    joinedAt = message.member.joinedAt;
                    break;

                default:
                    tag = member.user.tag;
                    avatarURL = member.user.displayAvatarURL;
                    roles = member.roles;
                    createdAt = member.user.createdAt;
                    joinedAt = member.joinedAt;
                    break;
            }

            switch (member.presence.status) {
                case 'online':
                    status = "En ligne";
                    break;

                case 'idle':
                    status = "Absent";
                    break;

                case 'dnd':
                    status = "Ne pas déranger";
                    break;

                default:
                    status = "Hors-ligne";
                    break;
            }

            let rolesName = [];

            roles.forEach(role => { rolesName.push(role.name) });

            const serverinfoembed = new Discord.RichEmbed()
                .setAuthor(message.author.username, message.author.displayAvatarURL)
                .setTitle('Informations sur l\'utilisateur')
                .setDescription(member)
                .addField("Nom", tag, true)
                .addField("Statut", status, true)
                .addField("Date de création du compte", moment(createdAt).locale("fr").format('llll'), true)
                .addField("Date d'arrivée sur le serveur", moment(joinedAt).locale("fr").format('llll'), true)
                .addField("Rôles", "`" + rolesName.join('`, `') + "`", true)
                .setColor("FAFAFA")
                .setThumbnail(avatarURL)
                .setFooter('Bot développé par LProgead#3667 de LShop')

            message.channel.send(serverinfoembed);
            return;
        }

        if (message.content === "+serverinfo") {
            const moment = require('moment');

            const serverinfoembed = new Discord.RichEmbed()
                .setAuthor(message.author.username, message.author.displayAvatarURL)
                .setTitle('Informations sur le serveur')
                .addField("Nom du serveur", message.guild.name, false)
                .addField("Identifiant du serveur", message.guild.id, true)
                .addField("Propriétaire du serveur", message.guild.owner, true)
                .addField("Date de création du serveur", moment(message.guild.createdAt).locale("fr").format('llll'), true)
                .addField("Nombre de membres", message.guild.members.size + " membres dont " + message.guild.members.filter(member => member.user.bot).size + " bots", true)
                .addField("Nombre de rôles", message.guild.roles.size, false)
                .addField("Nombre de salons", message.guild.channels.filter(channel => channel.type === "text").size + " salons textuels, " + message.guild.channels.filter(channel => channel.type === "voice").size + " salons vocaux et  " + message.guild.channels.filter(channel => channel.type === "category").size + " catégories", true)
                .addField("Statut des membres", message.guild.members.filter(member => member.presence.status === "online").size + " en ligne, " + message.guild.members.filter(member => member.presence.status === "idle").size + " en ligne, " + message.guild.members.filter(member => member.presence.status === "dnd").size + " en ne pas déranger et " + message.guild.members.filter(member => member.presence.status === "offline").size + " hors ligne", true)
                .setColor("FAFAFA")
                .setThumbnail(message.guild.iconURL)
                .setFooter('Bot développé par LProgead#3667 de LShop')

            message.channel.send(serverinfoembed);
            return;
        }

        if (message.content.startsWith("+roleinfo")) {
            const roleName = message.content.replace('+roleinfo ', '');

            const role = message.guild.roles.find('name', roleName);
            let hoist;
            let mentionable;

            switch (role.hoist) {
                case true:
                    hoist = "Oui";
                    break;

                default:
                    hoist = "Non";
                    break;
            }

            switch (role.mentionnable) {
                case true:
                    mentionnable = "Oui";
                    break;

                default:
                    mentionnable = "Non";
                    break;
            }

            const roleinfo = new Discord.RichEmbed()
                .setAuthor(message.author.username, message.author.displayAvatarURL)
                .setTitle('Message d\'aide')
                .addField('Nom', `\`\`\`${role.name}\`\`\``)
                .addField('ID', role.id)
                .addField('Position', role.position + '/' + message.guild.roles.size)
                .addField('Nombre de membres ayant ce rôle :', role.members.size)
                .addField('Couleur', role.color)
                .addField('Apparaît séparément ?', hoist)
                .addField('Mentionnable ?', mentionnable)
                .setColor('FAFAFA')
                .setFooter('Bot développé par LProgead#3667 de LShop')
                .setTimestamp()
            message.channel.send(roleinfo);
            return;
        }

        if (message.content.startsWith('+watch')) {
            if (fs.existsSync(message.channel.id)) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("Ce salon est déjà surveillé. Vous pouvez annuler la surveillance en utilisant la commande `+unwatch`.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            const args = message.content.split(' ');
            const tosend = message.content.replace(`+watch ${args[1]} ${args[2]} `, '');


            if (!args[1] || !args[2] || tosend === message.content) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("La syntaxe de cette commande est `+watch messages/articles Nombre de messages/articles avant mention Message a envoyer lorsque le nombre est atteint`.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            if (isNaN(args[2])) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("Le second arguement de surveillance doit être un chiffre.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            switch (args[1]) {
                case 'messages':
                    const okmsg = new Discord.RichEmbed()
                        .setAuthor(message.author.username, message.author.displayAvatarURL)
                        .setTitle('Surveillance du salon établie')
                        .setColor('FAFAFA')
                        .setFooter('Bot développé par LProgead#3667 de LShop')
                        .setTimestamp()
                    message.channel.send(okmsg);
                    fs.mkdirSync(message.channel.id);
                    fs.writeFileSync(message.channel.id + "/nbmen.txt", args[2]);
                    fs.writeFileSync(message.channel.id + "/men.txt", tosend);
                    fs.writeFileSync(message.channel.id + "/nbmsgs.txt", "1");
                    return;
                    break;

                case 'articles':
                    const okart = new Discord.RichEmbed()
                        .setAuthor(message.author.username, message.author.displayAvatarURL)
                        .setTitle('Surveillance du salon établie')
                        .setColor('FAFAFA')
                        .setFooter('Bot développé par LProgead#3667 de LShop')
                        .setTimestamp()
                    message.channel.send(okart);
                    console.log(tosend)
                    fs.mkdirSync(message.channel.id);
                    fs.writeFileSync(message.channel.id + "/nbmen.txt", args[2]);
                    fs.writeFileSync(message.channel.id + "/men.txt", tosend);
                    fs.writeFileSync(message.channel.id + "/nbarticles.txt", 0);
                    return;
                    break;

                default:
                    const err = new Discord.RichEmbed()
                        .setAuthor(message.author.username, message.author.displayAvatarURL)
                        .setTitle('Une erreur est survenue')
                        .setDescription("Le premier argument de surveillance doit être `messages` ou `articles`.")
                        .setColor('FF2200')
                        .setFooter('Bot développé par LProgead#3667 de LShop')
                        .setTimestamp()
                    message.channel.send(err);
                    return;
                    break;
            }

            fs.mkdirSync(message.channel.id);
        }

        if (message.content.startsWith('+unwatch')) {
            if (!fs.existsSync(message.channel.id)) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("Le salon n'est pas sous surveillance.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            else {
                const okart = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Surveillance du salon annulée')
                    .setColor('FAFAFA')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(okart);
                rimraf.sync(message.channel.id, { recursive: true });
                return;
            }
        }

        if (message.content.startsWith("+delbirthday")) {
            let del = 0;

            if (message.mentions.members.first()) {
                if (!message.member.hasPermission('ADMINISTRATOR')) return;

                fs.readdirSync('birthdays').forEach((file) => {
                    fs.readdirSync('birthdays/' + file).forEach((file1) => {
                        if (fs.existsSync(`birthdays/${file}/<@${message.mentions.members.first().user.id}>`)) {
                            fs.unlinkSync(`birthdays/${file}/<@${message.mentions.members.first().user.id}>`);

                            const okdel = new Discord.RichEmbed()
                                .setAuthor(message.mentions.members.first().user.username, message.mentions.members.first().user.displayAvatarURL)
                                .setTitle('Date d\'anniversaire supprimée')
                                .setColor('FAFAFA')
                                .setFooter('Bot développé par LProgead#3667 de LShop')
                                .setTimestamp()
                            message.channel.send(okdel);
                            del = 1;

                            if (!fs.readdirSync(`birthdays/${file}`)[0]) {
                                rimraf.sync(`birthdays/${file}`, { recursive: true });
                            }
                            return;
                        }
                    });
                });
            }

            if (message.content.startsWith('+delbirthday ')) {
                const date = message.content.replace('/', ':').replace('+delbirthday ', '');

                if (fs.existsSync('birthdays/' + date)) {
                    rimraf.sync(`birthdays/${date}`, { recursive: true });

                    const okdel = new Discord.RichEmbed()
                        .setAuthor(message.author.username, message.author.displayAvatarURL)
                        .setTitle('Date d\'anniversaire supprimée')
                        .setColor('FAFAFA')
                        .setFooter('Bot développé par LProgead#3667 de LShop')
                        .setTimestamp()
                    message.channel.send(okdel);
                    del = 1;
                    return;
                } else {
                    const err = new Discord.RichEmbed()
                        .setAuthor(message.author.username, message.author.displayAvatarURL)
                        .setTitle('Une erreur est survenue')
                        .setDescription("Cette date n'existe pas.")
                        .setColor('FF2200')
                        .setFooter('Bot développé par LProgead#3667 de LShop')
                        .setTimestamp()
                    message.channel.send(err);
                    return;
                }
            }

            fs.readdirSync('birthdays').forEach((file) => {
                fs.readdirSync('birthdays/' + file).forEach((file1) => {
                    if (fs.existsSync(`birthdays/${file}/<@${message.author.id}>`)) {
                        fs.unlinkSync(`birthdays/${file}/<@${message.author.id}>`);

                        const okdel = new Discord.RichEmbed()
                            .setAuthor(message.author.username, message.author.displayAvatarURL)
                            .setTitle('Date d\'anniversaire supprimée')
                            .setColor('FAFAFA')
                            .setFooter('Bot développé par LProgead#3667 de LShop')
                            .setTimestamp()
                        message.channel.send(okdel);
                        del = 1;
                        return;
                    }
                });
            });
        }

        if (message.content.startsWith('+setbirthday')) {
            const inarg = message.content.replace(`+setbirthday `, '');


            if (!inarg || inarg === message.content) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("La syntaxe de cette commande est `+setbirthday <Date (jj/mm)>`.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            if (!message.content.includes('/')) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("La date doit être précisée sous le format `jj/mm`.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            const args = inarg.split('/');

            if (!args[0] || !args[1]) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("La date doit être précisée sous le format `jj/mm`.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            if (args[0].length != 2 || args[1].length != 2) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("La date doit être précisée sous le format `jj/mm`.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            if (args[0] > 31 || args[1] > 12) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("Veuillez préciser une date valide.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            const bhsave = new Discord.RichEmbed()
                .setAuthor(message.author.username, message.author.displayAvatarURL)
                .setTitle('Date d\'anniversaire sauvegardée')
                .setColor('FAFAFA')
                .setFooter('Bot développé par LProgead#3667 de LShop')
                .setTimestamp()
            message.channel.send(bhsave);

            if (!fs.existsSync("birthdays/" + inarg.replace('/', ':'))) {
                fs.mkdirSync("birthdays/" + (inarg.replace('/', ':')).toString());
            }

            fs.writeFileSync(("birthdays/" + inarg.replace('/', ':') + `/<@${message.author.id}>`).toString(), '');
        }

        if (message.content.startsWith('+giveawaystart')) {
            let args = message.content.replace('+giveawaystart ', '').split(' ');

            if (!args[0] || !args[1] || !args[2]) {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("Veuillez respecter la syntaxe demandée pour cette commande: `+giveawaystart <Durée> <Nombre de gagnants> <Prix>`.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            message.delete();
            bot.giveawaysManager.start(message.channel, {
                time: ms(args[0]),
                prize: args.slice(2).join(" "),
                winnerCount: parseInt(args[1]),
                hostedBy: message.author
            });
        }

        if (message.content.startsWith('+giveawayreroll')) {
            let args = message.content.replace('+giveawayreroll ', '').split(' ');

            if (message.content.replace('+giveawayreroll ', '') === "+giveawayreroll") {
                const err = new Discord.RichEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL)
                    .setTitle('Une erreur est survenue')
                    .setDescription("Vous devez indiquer l'ID message du giveaway souhaité.")
                    .setColor('FF2200')
                    .setFooter('Bot développé par LProgead#3667 de LShop')
                    .setTimestamp()
                message.channel.send(err);
                return;
            }

            let messageID = args[0];
            bot.giveawaysManager.reroll(messageID).then(() => {
                message.channel.send("Un nouveau gagant a été choisi !");
            }).catch((err) => {
                message.channel.send("Aucun giveaway portant l'ID message `" + messageID + "` n'a été trouvé. Vérifiez puis ré-essayez.");
            });
        }

        if (message.content.startsWith('+giveawayend')) {
            let args = message.content.replace('+giveawayend ', '').split(' ');
            let messageID = args[0];
            bot.giveawaysManager.end(messageID).then(() => {
                message.channel.send("Le giveaway a bien été supprimé !");
            }).catch((err) => {
                message.channel.send("Aucun giveaway portant l'ID message `" + messageID + "` n'a été trouvé. Vérifiez puis ré-essayez.");
            });
        }
    }
});

function checkbh() {
    const heure = moment().format("HH:mm");
    if (heure != "00:00") return;
    const date = moment().format("DD:MM");
    const dates = fs.readdirSync("birthdays");
    if (!dates.includes(date)) return;

    const mbh = fs.readdirSync("birthdays/" + date);
    const msend = mbh.join(', ');

    const esend = new Discord.RichEmbed()
        .setTitle('Annonce d\'anniversaire')
        .setThumbnail('https://images.emojiterra.com/mozilla/512px/1f389.png')
        .setDescription(`Aujourd'hui, nous fêtons l'anniversaire de ${msend} !\nJoyeux anniversaire :tada:`)
        .setColor('FAFAFA')
        .setFooter('Bot développé par LProgead#3667 de LShop')
        .setTimestamp()

    bot.channels.get('719461608618721350').send(esend);
}

function stats() {
    const chmember = bot.channels.get('719464944923574324');
    chmember.setName(`Membres : ${bot.users.size}`);

    const chhumain = bot.channels.get('719465077165785088');
    chhumain.setName(`Humains : ${bot.users.filter(user => user.bot === false).size}`);

    const chbot = bot.channels.get('719465124456431689');
    chbot.setName(`Robots : ${bot.users.filter(user => user.bot).size}`);

    const chonline = bot.channels.get('719465229272088677');
    chonline.setName(`En ligne : ${bot.users.filter(user => user.bot === false).filter(user => user.presence.status === "online").size}`);

    const choffline = bot.channels.get('719465308355559494');
    choffline.setName(`Hors-ligne : ${bot.users.filter(user => user.bot === false).filter(user => user.presence.status === "offline").size}`);

    const chcategory = bot.channels.get('719465425750065212');
    chcategory.setName(`Catégories : ${bot.channels.filter(channel => channel.type === "category").size}`);

    const chtext = bot.channels.get('719465493743927297');
    chtext.setName(`Salons textuels : ${bot.channels.filter(channel => channel.type === "text").size}`);

    const chvoc = bot.channels.get('719465545480798259');
    chvoc.setName(`Salons vocaux : ${bot.channels.filter(channel => channel.type === "voice").size}`);

    const chrole = bot.channels.get('719465618314756117');
    chrole.setName(`Rôles : ${bot.guilds.get('695656222942298182').roles.size}`);
}