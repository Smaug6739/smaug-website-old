module.exports = async client => {
	console.log(`Logged in as ${client.user.tag}!`);

}