module.exports = async (client, message) => {
	const PREFIX = "*"

	if (!message.content.startsWith(PREFIX) || message.author.bot) return;
	const args = message.content.slice(PREFIX.length).split(/ +/);
	const commandName = args.shift().toLowerCase();

	const command = client.commands.find(cmd => cmd.name.includes(commandName));
	console.log(commandName)
	if (command) {
		console.log(true)
		command.execute(client, message, args);
	}
	else console.log(command)

}
