module.exports = {
	name: 'ping',
	description: 'Ping le bot',

	async execute(client, message, args) {

		message.channel.send('Pong !')
	}
}