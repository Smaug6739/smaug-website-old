const { MessageEmbed } = require('discord.js')
const ms = require('ms')
module.exports = {
	name: 'giveway',
	description: 'Gère des giveways',

	async execute(client, message, args) {

		const subCommand = args[0];
		switch (subCommand) {
			case 'add': {
				if (!args[3]) return message.channel.send('Invalids args length');
				client.giveawaysManager.start(message.channel, {
					time: ms(args[0]),
					prize: args.slice(2).join(" "),
					winnerCount: parseInt(args[1]),
					hostedBy: message.author
				});
				break;
			}
		}
	}
}